"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const FAQS = [
  {
    question: "What is WorkTag?",
    answer:
      "WorkTag is a digital trust platform that gives every professional a permanent, verified digital identity. Your customers scan your unique QR code to instantly view your verified profile, services, reviews, and contact information.",
  },
  {
    question: "How does the QR code work?",
    answer:
      "Every WorkTag profile generates a unique QR code linked permanently to your business. When someone scans the code with any smartphone camera, they are taken directly to your public profile. No app installation is required.",
  },
  {
    question: "Who needs a WorkTag?",
    answer:
      "Any business or professional who wants to build trust with customers before they make contact. Electricians, plumbers, caterers, fashion designers, real estate agents, mechanics, and thousands of other professionals use WorkTag to prove their identity and credibility.",
  },
  {
    question: "Is my information secure?",
    answer:
      "Yes. WorkTag uses end-to-end encryption for all data. Your personal information is never exposed without your consent. Only the information you choose to make public appears on your profile. We take security and privacy seriously.",
  },
  {
    question: "How do I get a physical tag?",
    answer:
      "When you create your WorkTag profile, you can order premium physical tags in various sizes and materials. Tags are delivered to your address and come with adhesive backing for easy placement on counters, walls, vehicles, and equipment.",
  },
  {
    question: "Can I update my profile after creation?",
    answer:
      "Yes. You can update your profile at any time from your dashboard. Services, contact details, photos, and business information can be changed whenever needed. Changes reflect instantly across all scans.",
  },
];

const item = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] } },
} as const;

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border-b border-[#E2E8F0]/40 last:border-b-0">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full py-5 text-left text-sm font-medium text-[#0F172A] transition-colors hover:text-[#0A3D91]"
      >
        {question}
        <svg
          viewBox="0 0 16 16"
          fill="none"
          className={`h-4 w-4 shrink-0 text-[#475569]/40 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M4 6l4 4 4-4" />
        </svg>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <p className="pb-5 text-sm leading-relaxed text-[#475569]">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function FAQSection() {
  return (
    <section id="faq" className="relative bg-[#F8FAFC]/20 py-24 sm:py-32 overflow-hidden">
      <div className="dot-grid absolute inset-0 pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-8">
        <div className="mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="text-center"
          >
            <span className="text-[11px] font-semibold tracking-[0.2em] text-[#0A3D91] uppercase">
              FAQ
            </span>
            <h2 className="mt-4 text-[clamp(2rem,3.5vw,3.2rem)] font-bold leading-[1.08] tracking-[-0.03em] text-[#0F172A]">
              Questions? Answered.
            </h2>
          </motion.div>

          <motion.div
            variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.05 } } }}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="mt-12 sm:mt-16"
          >
            {FAQS.map((faq) => (
              <motion.div key={faq.question} variants={item}>
                <FAQItem question={faq.question} answer={faq.answer} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
